

import java.util.Arrays;
import java.util.Scanner;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		
		String n="earth";
		String m="heart";
		
		 char a[]=n.toCharArray();
		 char b[]=m.toCharArray();
		 Arrays.sort(a);
		 Arrays.sort(b);
		 boolean result=Arrays.equals(a, b);
		 if(result==true)
		 {
			System.out.println("anagrams"); 
		 }
		 else
			 System.out.println("not anagrams");
		 
		 

	}

}

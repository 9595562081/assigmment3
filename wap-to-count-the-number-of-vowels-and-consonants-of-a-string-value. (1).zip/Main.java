

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="DEEPAK HR";
		char[] y=s.toCharArray();
		int size=y.length;
		int vowel=0;
		int consonant=0;
		int special=0;
		int i=0;
		while (i!=size)
		{
			if(y[i]>='A'&&y[i]<='Z')
			{
				if(y[i]=='A'||y[i]=='E'||y[i]=='I'||y[i]=='O'||y[i]=='U')
				{
					++vowel;		
				}
				else
				{
					++consonant;
				}
			}
			else
			{
				++special;
			}
			++i;
			
				
				
		}
		
		System.out.println(y);
		System.out.println("vowelcount is "+vowel);
		System.out.println("consonant count is "+consonant);
		System.out.println(" special symbol count is "+special);
	

}
}



public class Main {

	public static void main(String[] args) {
		String s="Think Twice";
		String s1=" ";
		  String a[]=s.split(" ");
		for(int i=s.length()-1;i>=0;i--)
		{
			s1=s1+s.charAt(i);
		}
		System.out.println(s1);
		
	}

}
